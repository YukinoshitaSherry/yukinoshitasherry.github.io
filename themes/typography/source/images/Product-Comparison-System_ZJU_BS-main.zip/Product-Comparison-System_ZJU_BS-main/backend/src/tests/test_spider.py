from app.services.spider import crawl_search_result, crawl_product_price


def test_spider():
    results = crawl_search_result('旺仔牛奶')
    print(crawl_product_price(results[0], force=True))
