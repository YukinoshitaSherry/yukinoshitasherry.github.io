import traceback
from datetime import datetime
from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.models.user import User
from app.models.product import Product
from app.models.alert import Alert
from app.models.subscribe import Subscribe
from app.utils.response import success_response, error_response, server_error_response
from app import db

user_bp = Blueprint('user', __name__)


@user_bp.route('', methods=['GET'])
@jwt_required()
def get_profile():
    try:
        current_user_id = int(get_jwt_identity())
        
        if not current_user_id:
            return error_response('未登录或token已过期', 401)
            
        user = User.query.get_or_404(current_user_id)

        # 未提示过的通知全都要，已经提示过的通知只显示最新的10条
        new_alerts = Alert.query.filter_by(user_id=current_user_id, notified=False)\
            .order_by(Alert.created_at.desc())\
            .all()
        old_alerts = Alert.query.filter_by(user_id=current_user_id, notified=True)\
            .order_by(Alert.created_at.desc())\
            .limit(10)\
            .all()
        alerts = [a.to_dict() for a in new_alerts + old_alerts]
        alerts = sorted(alerts, key=lambda x: x['created_at'], reverse=True)
        for i in range(len(alerts)):
            alerts[i]['product'] = Product.query.get_or_404(alerts[i]['product_id']).to_dict()

        # 标记这些通知为已经通知过并提交到数据库
        for a in new_alerts:
            a.notified = True
            db.session.add(a)
        db.session.commit()

        return success_response({
            'user': user.to_dict(),
            'alerts': alerts,
        })

    except Exception as e:
        return server_error_response()


@user_bp.route('', methods=['PATCH'])
@jwt_required()
def update_profile():
    try:
        user_id = get_jwt_identity()
        user = User.query.get_or_404(user_id)

        data = request.get_json()

        if 'username' in data:
            if len(data['username']) < 3 or len(data['username']) >= 50:
                return error_response('用户名格式不正确', 502)
            user.username = data['username']\

        if 'email' in data:
            if len(data['email']) < 3 or len(data['email']) >= 100:
                return error_response('邮箱格式不正确', 502)
            user.email = data['email']

        db.session.commit()
        return success_response(user.to_dict())

    except Exception as e:
        return server_error_response()


@user_bp.route('/subscribes', methods=['GET'])
@jwt_required()
def get_subscribes():
    try:
        user_id = get_jwt_identity()
        subscribes = Subscribe.query.filter_by(user_id=user_id).all()
        
        response = []
        for s in subscribes:
            data = s.to_dict()
            data['product'] = Product.query.get_or_404(s.product_id).to_dict()
            response.append(data)

        return success_response({
            'subscribes': response,
            'total': len(subscribes),
        })

    except Exception as e:
        return server_error_response()


@user_bp.route('/subscribes', methods=['PATCH'])
@jwt_required()
def create_subscribe():
    try:
        user_id = get_jwt_identity()
        data = request.get_json()

        if not data['product_id']:
            return error_response('商品ID不能为空', 601)
        
        product = Product.query.get_or_404(data['product_id'])
        
        # 删除该用户对该商品的所有已有订阅
        existing_subscribes = Subscribe.query.filter_by(
            user_id=user_id,
            product_id=data['product_id']
        ).all()
        for subscribe in existing_subscribes:
            db.session.delete(subscribe)
        
        if data['target_price']:
            target_price = float(data['target_price'])
        else:
            target_price = product.latest_price

        subscribe = Subscribe(
            user_id=user_id,
            product_id=data['product_id'],
            target_price=target_price,
            created_at=datetime.now(),
        )

        db.session.add(subscribe)
        db.session.commit()
        
        print('new subscribe:', subscribe.to_dict())

        return success_response(subscribe.to_dict())

    except Exception as e:
        traceback.print_exc()
        return server_error_response()


@user_bp.route('/subscribes/<int:id>', methods=['DELETE'])
@jwt_required()
def delete_subscribe(id):
    try:
        user_id = get_jwt_identity()

        subscribe = Subscribe.query.filter_by(user_id=user_id, id=id).first()
        if not subscribe:
            return error_response('未订阅该商品', 604)

        db.session.delete(subscribe)
        db.session.commit()

        return success_response(subscribe.to_dict())

    except Exception as e:
        return server_error_response()
