# 先打印一下，看看导入是否成功
# print("Importing blueprints...")
from app.api.auth import auth_bp
# print("auth_bp imported successfully")
from app.api.products import products_bp
# print("products_bp imported successfully")
from app.api.user import user_bp
# print("user_bp imported successfully")

__all__ = ['auth_bp', 'products_bp', 'user_bp'] 