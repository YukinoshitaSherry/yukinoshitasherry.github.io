from sqlalchemy import create_engine
from sqlalchemy_utils import database_exists, create_database
from app import create_app, db
from app.config import Config
from app.models.product import Product
from app.models.price import Price
from datetime import datetime

MAX_SAMPLE_PRODUCTS = 9
SAMPLE_PRODUCT_IMAGE_URL = 'http://www.cs.zju.edu.cn/_upload/tpl/04/b2/1202/template1202/img/pic_01.png'


def create_test_samples():
    for i in range(1, MAX_SAMPLE_PRODUCTS + 1):
        # 检查该id的商品是否已存在
        existing_product = Product.query.get(i)
        if existing_product is None:
            # 给所有测试样品之间添加相关性
            related_products = set(list(range(1, MAX_SAMPLE_PRODUCTS + 1)))
            related_products.remove(i)

            product = Product(
                id=i,
                platform='test',
                external_id=f'test-{i}',
                link=f"http://test/product-{i}",
                name=f"测试样品{i}",
                category='测试分类',
                description=f'这是一件编号为{i}的测试样品',
                image_url=SAMPLE_PRODUCT_IMAGE_URL,
                related_products_id=','.join(list(map(str, related_products))),
                latest_price=i * 11,
            )

            # 为每个商品创建一个初始价格记录
            price = Price(
                price=i * 11,  # 价格从101到110递增
                product_id=i,
                checked_at=datetime.now()
            )

            db.session.add(product)
            db.session.add(price)
            print(f"添加测试样品{i}成功!")

    db.session.commit()


def init_database():
    database_url = Config.SQLALCHEMY_DATABASE_URI

    engine = create_engine(database_url)

    if not database_exists(engine.url):
        create_database(engine.url)
        print("数据库创建成功!")

    app = create_app()
    with app.app_context():
        db.create_all()
        print("数据库表创建成功!")
        # 添加测试样品
        create_test_samples()
        print("测试样品数据添加完成!")


if __name__ == "__main__":
    init_database()
