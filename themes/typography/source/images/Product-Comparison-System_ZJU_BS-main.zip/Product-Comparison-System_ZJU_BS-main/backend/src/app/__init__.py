from flask import Flask, jsonify, request
from flask_cors import CORS
from app.extensions import db, jwt
from app.config import Config

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # 初始化扩展
    db.init_app(app)
    jwt.init_app(app)
    
    # 修改 CORS 配置
    CORS(app, resources={
        r"/api/*": {
            "origins": ["*"],
            "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"],
            "allow_headers": ["Content-Type", "Authorization"],
            "expose_headers": ["Authorization"]
        }
    })
    
    # 注册蓝图
    from app.api import auth_bp, products_bp, user_bp
    app.register_blueprint(auth_bp, url_prefix='/api')
    app.register_blueprint(products_bp, url_prefix='/api/products')
    app.register_blueprint(user_bp, url_prefix='/api/user')
    
    # 添加更多 JWT 错误处理
    @jwt.expired_token_loader
    def expired_token_callback(jwt_header, jwt_payload):
        return jsonify({
            'code': 401,
            'message': 'token已过期',
            'error': 'Token has expired'
        }), 401

    @jwt.invalid_token_loader
    def invalid_token_callback(error_string):
        print("无效的token:", error_string)  # 添加调试信息
        return jsonify({
            'code': 422,
            'message': '无效的认证令牌',
            'error': str(error_string)
        }), 422

    @jwt.unauthorized_loader
    def unauthorized_callback(error_string):
        return jsonify({
            'code': 401,
            'message': '缺少认证令牌',
            'error': str(error_string)
        }), 401
        
    @jwt.needs_fresh_token_loader
    def token_not_fresh_callback(jwt_header, jwt_payload):
        return jsonify({
            'code': 401,
            'message': '需要新的token',
            'error': 'Fresh token required'
        }), 401

    return app 
