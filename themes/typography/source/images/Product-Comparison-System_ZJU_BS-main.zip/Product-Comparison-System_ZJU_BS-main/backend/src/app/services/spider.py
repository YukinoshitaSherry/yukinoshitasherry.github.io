import re
# import jieba
import requests
import random
import concurrent.futures
from bs4 import BeautifulSoup
from functools import partial
from datetime import datetime, timedelta
from app.models.price import Price
from app.models.product import Product
from app.services.persistence import persistent_price, persistent_product


USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"


class SpiderException(Exception):
    pass


def normalize_product_name(name):
    stopwords = [
        '移动端', 'PC端', '电脑端', '手机端',
        '淘宝', '天猫', '拼多多', '京东', '亚马逊', '拼多多',
        '电信', '专享', '移动', '联通', '百亿补贴',
        'others', 'other', '中国',
    ]
    name = name.replace(':', ' ').replace('：', ' ').replace('、', ' ')
    for stopword in stopwords:
        name = name.replace(stopword, '')
    return re.sub(r'\s+', ' ', name.strip())


def parse_price(text):
    if not text or not text[0].isdigit():
        return None

    matches = re.findall(r'\d+\.?\d*', text)
    if matches:
        numbers = [float(match) for match in matches]
        return round(sum(numbers) / len(numbers), 2)

    return None


PRODUCT_FETCH_DELAY = timedelta(days=1)


def crawl_product_price(product, force=False):
    """
    爬取指定物品最新价格
    """
    if product.platform == 'test':
        return persistent_price(Price(
            product_id=product.id,
            price=round(max(float(product.latest_price) * random.uniform(0.5, 1.5), 0.01), 2),
            checked_at=datetime.now()
        ))

    if not force and product.updated_at + PRODUCT_FETCH_DELAY > datetime.now():
        return Price.query.filter_by(product_id=product.id).order_by(Price.checked_at.desc()).first()

    assert product.external_id.startswith('smzdm-')
    smzdm_id = product.external_id[6:]
    url = f"https://www.smzdm.com/p/{smzdm_id}/"

    response = requests.get(url, headers={'User-Agent': USER_AGENT})
    response.raise_for_status()

    soup = BeautifulSoup(response.text, 'html.parser')
    price_large = soup.find('span', class_='price-large')
    if price_large:
        num = price_large.find('span', class_='num')
        if num:
            return persistent_price(Price(
                product_id=product.id,
                price=parse_price(num.text),
                checked_at=datetime.now()
            ))

    raise SpiderException("Price not found")


def crawl_search_result(query):
    def crawl_url(url, platform):
        print(f"crawling url root: {url}")

        headers = {
            "User-Agent": USER_AGENT
        }

        response = requests.get(url, headers=headers)
        if response.status_code != 200:
            raise SpiderException(f"HTTP status code: {response.status_code}")

        soup = BeautifulSoup(response.text, 'html.parser')
        products = []

        ul = soup.find('ul', id='feed-main-list')
        if ul:
            for li in ul.find_all('li'):
                product = Product(
                    platform=platform,
                    external_id='',
                    link='',
                    name='',
                    category='',
                    description='',
                    image_url='',
                    related_products_id=None,
                    latest_price=None,
                    updated_at=datetime.now(),
                )

                try:
                    img_div = li.find('div', class_='z-feed-img')
                    a_tag = img_div.find('a')
                    href = a_tag.get('href', '')
                    product.external_id = 'smzdm-' + href.split('/')[4]

                    img = a_tag.find('img')
                    product.image_url = f"https:{img.get('src', '')}"

                    # 价格
                    content_div = li.find('div', class_='z-feed-content')
                    title = content_div.find('h5')
                    highlight = title.find('div', class_='z-highlight')
                    price = parse_price(highlight.text)
                    if price is None:
                        continue
                    product.latest_price = price
                    highlight.decompose()

                    nowrap = title.find('a', class_='feed-nowrap')
                    product.name = normalize_product_name(nowrap.text)

                    # 描述
                    describe_top = content_div.find('div', class_='feed-block-descripe-top')
                    product.description = describe_top.text.strip()
                    if len(product.description) == 0:
                        continue
                    # 来源链接
                    feed_foot_r = content_div.find('div', class_='z-feed-foot-r')
                    feed_link_btn = feed_foot_r.find('div', class_='feed-link-btn')
                    a_tag = feed_link_btn.find('a')
                    product.link = a_tag.get('href', '')
                except Exception as e:
                    print(f"> error: {e}")
                    continue

                # print('> found:', product.to_dict())
                products.append(product)

        print(f"crawled {len(products)} products from {platform}")
        # print(f"products: {products}")

        return products

    # segments = '+'.join(jieba.cut(query)) # 经过测试，分词的效果还没有不分词好
    segments = '+'.join(re.split(r'\s+', query))
    base_url = f"https://search.smzdm.com/?c=home&s={segments}&order=score&v=b&mx_v=b"

    url_jd = f"{base_url}&mall_id=183"
    url_pdd = f"{base_url}&mall_id=8645"
    url_amazon = f"{base_url}&mall_id=269"

    # 并行爬取
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = [
            executor.submit(crawl_url, url_jd, "jd"),
            executor.submit(crawl_url, url_pdd, "pdd"),
            executor.submit(crawl_url, url_amazon, "amazon")
        ]
        results = []
        for future in concurrent.futures.as_completed(futures):
            try:
                results.extend(future.result())
            except Exception as e:
                print(f"爬取过程发生错误: {e}")

    current_time = datetime.now()
    products = []

    for product_data in results:
        # 持久化商品
        product = persistent_product(product_data)
        products.append(product)

        # 持久化价格
        persistent_price(Price(
            product_id=product.id,
            price=product_data.latest_price,
            checked_at=current_time
        ))

    response = []
    for product in products:
        related_products = []
        for another_product in products:
            if product.id != another_product.id:
                related_products.append(another_product.id)
        product.related_products = ','.join(list(map(str, related_products)))
        # 初步得到相关商品列表，会在持久化时进行抽样处理
        response.append(persistent_product(product))

    return response
