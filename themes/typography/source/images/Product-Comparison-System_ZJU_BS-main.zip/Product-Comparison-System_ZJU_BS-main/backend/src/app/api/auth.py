import os
import time
import hashlib
import requests
import traceback
from pathlib import Path
from flask import Blueprint, request, jsonify, send_file, current_app
from flask_jwt_extended import create_access_token
from functools import wraps
from app.services.spider import USER_AGENT
from app.models import User
from app.extensions import db


CACHE_EXPIRE_DAYS = 30


auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/register', methods=['POST'])
def register():
    try:
        data = request.get_json()

        # 检查必要字段
        if not all(k in data for k in ('email', 'username', 'password')):
            return jsonify({
                'code': 400,
                'msg': '缺少必要字段',
                'data': None
            })

        # 检查邮箱是否已存在
        if User.query.filter_by(email=data['email']).first():
            return jsonify({
                'code': 1,
                'msg': 'email already exists',
                'data': None
            })

        # 检查用户名是否已存在
        if User.query.filter_by(username=data['username']).first():
            return jsonify({
                'code': 1, 
                'msg': 'username already exists',
                'data': None
            })

        # 检查用户名和邮箱的长度是否合法
        if len(data['username']) < 2 or len(data['username']) > 50:
            return jsonify({
                'code': 1,
                'msg': '用户名长度不合法(2-50字符)',
                'data': None
            })
            
        if len(data['email']) < 3 or len(data['email']) > 100:
            return jsonify({
                'code': 1,
                'msg': '邮箱长度不合法(3-100字符)',
                'data': None
            })

        # 创建新用户
        user = User(
            email=data['email'],
            username=data['username']
        )
        user.set_password(data['password'])

        db.session.add(user)
        db.session.commit()

        return jsonify({
            'code': 0,
            'msg': '注册成功',
            'data': user.to_dict()
        })

    except Exception as e:
        return jsonify({
            'code': 500,
            'msg': '服务器内部错误',
            'data': None
        })


@auth_bp.route('/login', methods=['POST'])
def login():
    try:
        data = request.get_json()

        # 检查必要字段
        if not all(k in data for k in ('email', 'password')):
            return jsonify({
                'code': 400,
                'message': '缺少必要字段',
                'data': None
            })

        # 通过邮箱查找用户
        user = User.query.filter_by(email=data['email']).first()

        if not user or not user.check_password(data['password']):
            return jsonify({
                'code': 401,
                'message': '邮箱或密码错误',
                'data': None
            })

        # 生成token时添加更多调试信息
        print("正在为用户生成token:", user.id)
        access_token = create_access_token(
            identity=str(user.id),
            additional_claims={
                "type": "access",
                "user_id": user.id
            }
        )
        print("生成的token:", access_token)

        return jsonify({
            'code': 0,
            'message': '登录成功',
            'data': {
                'token': access_token,
                'user': user.to_dict()
            }
        })

    except Exception as e:
        return jsonify({
            'code': 500,
            'message': '服务器内部错误',
            'data': None
        })




def get_cache_dir():
    if not hasattr(get_cache_dir, 'cache_dir'):
        get_cache_dir.cache_dir = Path(current_app.root_path).parent / "cache/images"
        get_cache_dir.cache_dir.mkdir(parents=True, exist_ok=True)
    return get_cache_dir.cache_dir


@auth_bp.route('/img-proxy/<path:image_url>', methods=['GET'])
def img_proxy(image_url):
    try:
        # 获取缓存目录
        cache_dir = get_cache_dir()
        
        # 确保 URL 是完整的 URL
        if not image_url.startswith(('http://', 'https://')):
            return jsonify({
                'code': 400,
                'message': '无效的图片URL',
                'data': None
            })

        # 对完整 URL 进行 MD5 哈希
        url_hash = hashlib.md5(image_url.encode()).hexdigest()
        cache_path = cache_dir / url_hash
        print(f"cache_path: {cache_path}")

        # 检查缓存是否存在且未过期
        if cache_path.exists():
            # 检查文件是否过期
            file_time = os.path.getmtime(cache_path)
            if time.time() - file_time < CACHE_EXPIRE_DAYS * 24 * 3600:
                return send_file(
                    str(cache_path.absolute()),
                    mimetype='image/*',
                    as_attachment=False  # 设置为 False 表示在浏览器中显示而不是下载
                )
            else:
                # 删除过期文件
                cache_path.unlink()

        # 设置请求头，模拟浏览器请求
        headers = {
            'User-Agent': USER_AGENT
        }

        # 下载图片
        response = requests.get(
            image_url,
            stream=True,
            headers=headers,
            timeout=600  # 添加超时设置
        )

        if response.status_code != 200:
            return jsonify({
                'code': response.status_code,
                'message': '获取图片失败',
                'data': None
            })

        # 保存到缓存
        with open(cache_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

        # 设置正确的 Content-Type
        content_type = response.headers.get('Content-Type', 'image/jpeg')

        # 返回图片
        return send_file(
            str(cache_path.absolute()),
            mimetype=content_type,
            as_attachment=False  # 设置为 False 表示在浏览器中显示而不是下载
        )

    except requests.exceptions.RequestException as e:
        return jsonify({
            'code': 400,
            'message': '图片下载失败',
            'data': None
        })

    except Exception as e:
        traceback.print_exc()
        return jsonify({
            'code': 500,
            'message': '服务器内部错误',
            'data': None
        })