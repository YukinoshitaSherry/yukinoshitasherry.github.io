import random
import logging
from datetime import datetime, timedelta
from app import db
from app.models.price import Price
from app.models.product import Product
from app.models.subscribe import Subscribe
from app.models.alert import Alert

RELATED_PRODUCTS_LIMIT = 10


def persistent_price(price_data):
    # 检查是否已存在相同的价格记录
    price = Price.query.filter_by(product_id=price_data.product_id, checked_at=price_data.checked_at).first()
    if price:
        return price  # 如果已经被持久化则直接返回

    try:
        # 创建新的价格记录
        price = price_data
        db.session.add(price)

        # 更新对应商品的实时价格
        product = Product.query.get(price.product_id)
        if product.latest_price is None or product.latest_price != price.price:
            product.latest_price = price.price
            db.session.add(product)

        # 获取最新价格记录
        latest_price = Price.query.filter_by(product_id=price.product_id)\
            .order_by(Price.checked_at.desc())\
            .first()

        # 如果当前价格没有优惠，则需要发布通知（更新所有相关的订阅）
        if latest_price is None or price.price < latest_price.price:
            subscribes = Subscribe.query.filter_by(product_id=price.product_id).all()
            for subscribe in subscribes:
                if subscribe.target_price is None or price.price < subscribe.target_price:
                    alert = Alert(
                        user_id=subscribe.user_id,
                        product_id=price.product_id,
                        old_price=latest_price.price if latest_price else None,
                        latest_price=price.price,
                        created_at=datetime.now(),
                        notified=False
                    )
                    db.session.add(alert)

        db.session.commit()
        return price

    except Exception as e:
        db.session.rollback()
        raise e


def persistent_product(product_data):
    '''
    持久化 product 数据并返回 Product 对象
    '''
    print('persistent product', product_data.to_dict())

    try:
        # 根据 external_id 和 platform 查询该项目是否已经存在，如果存在则更新，否则直接创建
        product = Product.query.filter_by(external_id=product_data.external_id, platform=product_data.platform).first()
        if product:
            product.updated_at = product_data.updated_at

            # 各种参数，如果不为空就更新
            if product_data.name is not None:
                product.name = product_data.name
            if product_data.category is not None:
                product.category = product_data.category
            if product_data.image_url is not None:
                product.image_url = product_data.image_url
            if product_data.link is not None:
                product.link = product_data.link
            if product_data.description is not None:
                product.description = product_data.description
            if product_data.latest_price is not None:
                product.latest_price = product_data.latest_price

            # 对于 related_products_id 需要进行特殊处理
            old_related_products = []
            new_related_products = []
            if product.related_products_id:
                old_related_products = product.related_products_id.split(',')
            if product_data.related_products_id:
                new_related_products = product_data.related_products_id.split(',')

            related_products_set = set(old_related_products + new_related_products)
            if product.id in related_products_set:
                related_products_set.remove(product.id)
            related_products = list(related_products_set)
            if len(related_products) > RELATED_PRODUCTS_LIMIT:
                related_products = random.sample(related_products, RELATED_PRODUCTS_LIMIT)

            product.related_products_id = ','.join(related_products)
            db.session.add(product)

        else:
            product = product_data
            product.created_at = product.updated_at
            db.session.add(product)

        db.session.commit()
        return product

    except Exception as e:
        db.session.rollback()
        raise e
