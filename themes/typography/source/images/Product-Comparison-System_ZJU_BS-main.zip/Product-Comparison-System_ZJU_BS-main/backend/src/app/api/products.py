from flask import Blueprint, request
from app.models.product import Product
from app.models.price import Price
from app.utils.response import success_response, error_response,  server_error_response
from app.services.spider import crawl_product_price, crawl_search_result
from sqlalchemy import or_
import traceback

products_bp = Blueprint('products', __name__)


@products_bp.route('/<int:id>', methods=['GET'])
def get_product(id):
    try:
        product = Product.query.get(id)
        if product is None:
            return error_response('商品未找到', 404)
        
        crawl_product_price(product)
        prices = Price.query.filter_by(product_id=id).order_by(Price.checked_at.desc()).all()

        related_ids = product.related_products_id.split(',') if product.related_products_id else []
        related_products = Product.query.filter(Product.id.in_(related_ids)).all() if related_ids else []

        return success_response({
            'product': product.to_dict(),
            'prices': [p.to_dict() for p in prices],
            'related_products': [p.to_dict() for p in related_products]
        })

    except Exception as e:
        traceback.print_exc()
        return server_error_response()


@products_bp.route('/search', methods=['GET'])
def search():
    try:
        # 获取查询参数
        keyword = request.args.get('keyword', '').strip()
        platform = request.args.get('platform')
        # category = request.args.get('category')
        # min_price = request.args.get('min_price', type=float)
        # max_price = request.args.get('max_price', type=float)
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        
        if keyword == '':
            return error_response('关键词不能为空', 620)

        products = crawl_search_result(keyword)

        return success_response({
            'products': [product.to_dict() for product in products],
            'total': len(products),
        })

    except Exception as e:
        traceback.print_exc()
        return server_error_response()
