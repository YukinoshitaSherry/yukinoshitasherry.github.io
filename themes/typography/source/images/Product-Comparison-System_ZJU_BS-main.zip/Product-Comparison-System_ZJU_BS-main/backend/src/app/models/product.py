from app import db
from app.models.base import BaseModel


class Product(BaseModel):
    __tablename__ = 'products'

    id = db.Column(db.Integer, primary_key=True)
    platform = db.Column(db.String(255), nullable=False)
    external_id = db.Column(db.String(255), nullable=False)
    link = db.Column(db.Text)
    name = db.Column(db.String(255), nullable=False)
    category = db.Column(db.String(255))
    description = db.Column(db.Text)
    image_url = db.Column(db.String(255))
    related_products_id = db.Column(db.Text)  # 用逗号分割的相关 product 列表
    latest_price = db.Column(db.DECIMAL(10, 2))

    # 关联关系
    prices = db.relationship('Price', backref='product', lazy='dynamic')
    subscribes = db.relationship('Subscribe', backref='product', lazy='dynamic')
    alerts = db.relationship('Alert', backref='product', lazy='dynamic')
