def success_response(data):
    data['code'] = 200
    return data


def error_response(message="Error", code=500):
    return {
        "code": code,
        "message": message,
    }


def server_error_response():
    return error_response('服务器内部错误', 500)
