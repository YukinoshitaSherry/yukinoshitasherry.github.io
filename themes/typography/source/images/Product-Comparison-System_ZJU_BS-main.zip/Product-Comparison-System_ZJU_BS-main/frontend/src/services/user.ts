import { api } from './api';

export interface UserProfile {
  id: number;
  username: string;
  email: string;
  avatar: string;
  created_at: string;
}

export interface PriceAlert {
  id: number;
  product_id: number;
  target_price: number;
  created_at: string;
}

export interface UserResponse extends Response {
  user: UserProfile;
  alerts: PriceAlert[];
}

export const userAPI = {
  // 获取用户信息
  getUserInfo: async () => {
    try {
      const response: UserResponse = await api.get('/user', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      console.log('!!!', response);
      return {
        code: 0,
        data: {
          user: response.user,
          alerts: response.alerts,
        },
        msg: 'success'
      };
    } catch (error) {
      console.error('获取用户信息失败:', error);
      throw error;
    }
  },

  // 更新用户信息
  updateProfile: async (data: Partial<UserProfile>) => {
    return api.put('/user', data, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
  },

  // 更新头像
  updateAvatar: async (file: File) => {
    const formData = new FormData();
    formData.append('avatar', file);
    return api.put('/user/avatar', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
    });
  },

  // 创建价格提醒
  createSubscribes: async (data: { product_id: number; target_price: number }) => {
    return api.patch('/user/subscribes', data, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
  },

  // 删除价格提醒
  deleteSubscribes: async (id: number) => {
    return api.delete(`/user/subscribes/${id}`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
    });
  },

  // 获取订阅商品列表
  getSubscribes: async () => {
    return api.get('/user/subscribes', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    });
  },
};
