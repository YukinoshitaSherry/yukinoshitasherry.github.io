import { api } from './api';
import { ProductDetailResponse, SubscribeResponse } from '../types/product';
import { SearchParams, SearchResponse } from '../types/api';

export const productAPI = {
  // 搜索商品
  searchProducts: async (params: SearchParams): Promise<SearchResponse> => {
    const queryString = new URLSearchParams(params as any).toString();
    return api.get(`/products/search?${queryString}`);
  },

  // 获取商品详情
  getProductDetail: async (id: number): Promise<ProductDetailResponse> => {
    return api.get(`/products/${id}`);
  },

  // 获取热门商品
  getHotProducts: async (): Promise<SearchResponse> => {
    return api.get('/products/hot');
  },
}; 