import React from 'react';
import { Container, Box, Button } from '@mui/material';

const Hero = () => {
  return (
    <Container
      sx={{
        pt: { xs: 4, sm: 12 },
        pb: { xs: 8, sm: 16 },
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
      }}
    >
      <Box
        sx={{
          width: '100%',
          textAlign: 'center',
        }}
      >
        {/* 其他文字内容 */}
      </Box>
      
      <Button
        variant="contained"
        color="primary"
        size="large"
        sx={{
          minWidth: 200,
        }}
      >
        Start now
      </Button>
    </Container>
  );
};

export default Hero;
