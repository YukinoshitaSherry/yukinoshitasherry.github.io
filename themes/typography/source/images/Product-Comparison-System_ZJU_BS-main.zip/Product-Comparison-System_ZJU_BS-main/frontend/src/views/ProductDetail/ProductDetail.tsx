import React from 'react';
import { 
  Container, 
  Grid, 
  Typography, 
  Paper,
  Box,
  Button,
  CircularProgress,
  Alert,
  Chip,
  Stack,
  Link,
  Breadcrumbs
} from '@mui/material';
import { useParams, useNavigate } from 'react-router-dom';
import ProductCard from '../../components/Product/ProductCard';
import PriceHistoryChart from '../../components/Product/PriceHistoryChart';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import { productAPI } from '../../services/product';
import type { ProductDetailResponse } from '../../types/product';
import PriceAlert from '../../components/Product/PriceAlert';
import { Link as RouterLink } from 'react-router-dom';
import HomeIcon from '@mui/icons-material/Home';
import SearchIcon from '@mui/icons-material/Search';
import { getImageProxy, getPlatformName } from '../../services/api';

const ProductDetail: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = React.useState(true);
  const [error, setError] = React.useState<string | null>(null);
  const [productDetail, setProductDetail] = React.useState<any>(null);

  console.log('!!', loading, error, productDetail);
  React.useEffect(() => {
    const fetchProductDetail = async () => {
      if (!id) return;
      
      setLoading(true);
      setError(null);
      try {
        const response = await productAPI.getProductDetail(Number(id));
        if (response.code === 200) {
          setProductDetail(response);
        } else {
          setError(response.msg);
        }
      } catch (err) {
        console.log('获取商品详情失败', err);
        setError('获取商品详情失败');
      } finally {
        setLoading(false);
      }
    };

    fetchProductDetail();
  }, [id]);

  if (loading) return <CircularProgress />;
  console.log('!!', loading, error, productDetail);
  if (error) return <Alert severity="error">{error}</Alert>;
  if (!productDetail) return <Alert severity="info">未找到商品信息</Alert>;

  const { product, related_products, prices } = productDetail;

  const formatDisplayValue = (value: string | null | undefined): string => {
    if (!value || value === 'none' || value === '') {
      if (value === 'category') {
        return '数码';
      }
      return '数码';
    }
    return value;
  };

  return (
    <Container maxWidth="lg" sx={{ mt: 15, mb: 8 }}>
      {/* 添加面包屑导航 */}
      <Breadcrumbs aria-label="breadcrumb" sx={{ mb: 3 }}>
        <Link 
          component={RouterLink} 
          to="/"
          color="inherit"
          sx={{ display: 'flex', alignItems: 'center' }}
        >
          <HomeIcon sx={{ mr: 0.5 }} fontSize="inherit" />
          首页
        </Link>
        <Link
          component={RouterLink}
          to="/search"
          color="inherit"
          sx={{ display: 'flex', alignItems: 'center' }}
        >
          <SearchIcon sx={{ mr: 0.5 }} fontSize="inherit" />
          商品搜索
        </Link>
        {product.category && (
          <Link
            component={RouterLink}
            to={`/search?category=${product.category}`}
            color="inherit"
          >
            {product.category}
          </Link>
        )}
        <Typography color="text.primary">
          {product.name}
        </Typography>
      </Breadcrumbs>
      
      {/* 商品基本信息区域 */}
      <Paper elevation={3} sx={{ p: 4, mb: 4 }}>
        <Grid container spacing={4}>
          {/* 左侧商品图片 */}
          <Grid item xs={12} md={6}>
            <Box sx={{ width: '100%', height: '400px', position: 'relative' }}>
              <img
                src={getImageProxy(product.image_url)}
                alt={product.name}
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'contain'
                }}
              />
            </Box>
          </Grid>
          
          {/* 右侧商品信息 */}
          <Grid item xs={12} md={6}>
            <Typography variant="h4" gutterBottom>
              {product.name}
            </Typography>
            
            <Typography variant="body1" color="text.secondary" paragraph>
              {product.description}
            </Typography>

            <Stack spacing={2}>
              <Box>
                <Typography variant="subtitle2" gutterBottom>
                  商品信息
                </Typography>
                <Stack direction="row" spacing={1}>
                  <Chip label={`类别: ${formatDisplayValue(product.category)}`} color="primary" />
                  <Chip label={`平台: ${getPlatformName(product.platform)}`} />
                </Stack>
              </Box>

              <Box>
                <Typography variant="subtitle2" gutterBottom>
                  最新价格
                </Typography>
                <Typography variant="h5" color="error">
                  ¥{product.latest_price}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  更新时间: {new Date(product.updated_at).toLocaleString()}
                </Typography>
              </Box>

              <Box>
                <Link 
                  href={product.link}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button variant="contained" color="primary">
                    去购买
                  </Button>
                </Link>
              </Box>
            </Stack>
          </Grid>
        </Grid>
      </Paper>

      {/* 价格历史走势图 */}
      <Paper elevation={3} sx={{ p: 4, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
          <Typography variant="h5">
            价格走势
          </Typography>
          <PriceAlert productId={product.id} currentPrice={product.latest_price} />
        </Box>
        <Box sx={{ height: 400, mt: 2 }}>
          <PriceHistoryChart data={prices} />
        </Box>
        {prices.length <= 2 && (
          <Typography 
            variant="caption" 
            color="text.secondary" 
            sx={{ display: 'block', mt: 1, textAlign: 'center' }}
          >
            注：数据点较少，仅供参考
          </Typography>
        )}
      </Paper>


      {/* 返回按钮移到底部 */}
      <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
        <Button
          variant="contained"
          startIcon={<ArrowBackIcon />}
          onClick={() => navigate(-1)}
          sx={{
            width: '200px',
            bgcolor: 'primary.light',
            '&:hover': {
              bgcolor: 'primary.main',
            }
          }}
        >
          返回列表
        </Button>
      </Box>
    </Container>
  );
};

export default ProductDetail;
