import { Product } from './product';

// API响应的通用接口
export interface ApiResponse<T> {
  code: number;
  data: T;
  message?: string;
}

// 分页参数接口
export interface PaginationParams {
  page?: number;
  pageSize?: number;
}

// 分页响应接口
export interface PaginatedResponse<T> {
  total: number;
  current_page: number;
  per_page: number;
  data: T[];
}

// 先定义搜索模式的联合类型
export type SearchMode = 'exact' | 'fuzzy' | 'multiple-and' | 'multiple-or';

// 定义搜索参数接口
export interface SearchParams {
  keyword: string;
  mode?: SearchMode;
  page?: number;
  pageSize?: number;
}

export interface SearchResponse {
  code: number;
  products: Product[];  // 直接在顶层定义 products 数组
  total: number;
}

export interface SubscribeResponse {
  code: number;
  subscribes: Subscribe[];
}




