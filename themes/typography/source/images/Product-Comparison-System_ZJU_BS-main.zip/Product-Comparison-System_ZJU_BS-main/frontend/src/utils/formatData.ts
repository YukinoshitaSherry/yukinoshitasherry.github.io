export const formatDisplayValue = (value: string | null | undefined): string => {
  if (!value || value === 'none' || value === '') {
    return '数据暂缺';
  }
  return value;
}; 