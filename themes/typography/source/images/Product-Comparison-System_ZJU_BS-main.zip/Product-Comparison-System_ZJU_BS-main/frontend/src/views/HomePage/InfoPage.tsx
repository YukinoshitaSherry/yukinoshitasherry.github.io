import React from 'react';
import { Box, Container, Typography, Card, CardContent, Grid, Paper, Theme } from '@mui/material';
import { styled } from '@mui/material/styles';
import RocketLaunchIcon from '@mui/icons-material/RocketLaunch';
import PrecisionManufacturingIcon from '@mui/icons-material/PrecisionManufacturing';
import BusinessIcon from '@mui/icons-material/Business';
import SearchIcon from '@mui/icons-material/Search';
import CompareArrowsIcon from '@mui/icons-material/CompareArrows';
import PersonIcon from '@mui/icons-material/Person';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { LocalOfferOutlined, CompareOutlined, TrendingUpOutlined, NotificationsActiveOutlined, SearchOutlined, SecurityOutlined, SpeedOutlined, DevicesOutlined, SupportOutlined } from '@mui/icons-material';
import LogoBig from '../../assets/img/logo-big.jpg';

const StyledCard = styled(Card)(({}) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: 'transform 0.3s ease-in-out',
  '&:hover': {
    transform: 'translateY(-8px)',
  },
}));

const features = [
  {
    icon: <LocalOfferOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '实惠购物',
    description: '实时追踪多平台价格，轻松找到最优惠',
  },
  {
    icon: <CompareOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '一键比价',
    description: '自动对比多平台同款商品，省时省力',
  },
  {
    icon: <TrendingUpOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '历史趋势',
    description: '历史价格走势分析，避免虚假促销',
  },
  {
    icon: <NotificationsActiveOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '降价提醒',
    description: '设置价格提醒，降价自动通知',
  },
  {
    icon: <SearchOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '智能搜索',
    description: '快速定位目标商品，支持多维度筛选',
  },
  {
    icon: <SecurityOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '安全保障',
    description: '安全可靠的购物链接，放心购物',
  },
  {
    icon: <SpeedOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '快速响应',
    description: '毫秒级响应，实时更新价格信息',
  },
  {
    icon: <DevicesOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '平台支持',
    description: '支持主流电商平台，覆盖面广',
  },
  {
    icon: <SupportOutlined sx={{ fontSize: 40, color: 'primary.main' }} />,
    title: '贴心服务',
    description: '专业的客服团队，解答您的疑问',
  },
];

const ProductInfo: React.FC = () => {
  return (
    <Container maxWidth="lg" sx={{ mt: 15, mb: 8 }}>
      {/* Logo部分 */}
      <Box
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          mb: 6,
        }}
      >
        {/* Logo图片 */}
        <Box
          component="img"
          src="/src/assets/img/logo.png"
          alt="Good-Goods Logo"
          sx={{
            width: '120px', // 缩小logo尺寸
            height: 'auto',
            mb: 3, // 增加与下方文字的间距
          }}
        />

        {/* 系统名称 */}
        <Typography
          variant="h3"
          align="center"
          sx={{
            mb: 2,
            fontWeight: 'bold',
            fontSize: { xs: '2rem', sm: '2.5rem' },
            '& .highlight': {
              color: 'primary.main', // 使用与下方相同的蓝色
            },
          }}
        >
          <span className="highlight">Good-Goods&nbsp;商品比价系统</span>
        </Typography>

        {/* 联系方式 */}
        <Typography
          variant="subtitle1"
          align="center"
          sx={{
            color: 'text.primary',
            mb: 4,
          }}
        >
          联系我们：3220104147@zju.edu.cn 余卓耘
        </Typography>
      </Box>

      {/* 寓意说明卡片 */}
      <Paper elevation={3} sx={{ p: 4, mb: 6 }}>
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center', // 垂直居中
            gap: 0, // 减小左右内容间距，从 4 改为 2
            justifyContent: 'space-between', // 添加这行来优化间距分布
          }}
        >
          {/* 左侧文字内容 */}
          <Box sx={{ flex: '1 1 auto', maxWidth: '70%' }}>
            {' '}
            {/* 限制左侧内容最大宽度 */}
            <Typography variant="h5" gutterBottom color="primary.main">
              产品寓意
            </Typography>
            <Typography paragraph>• 产品图标为左右两个G&O扭合而成，含有∞无穷大，寓意为选择多，也希望本系统可以成为用户与商家之间的纽带。</Typography>
            <Typography paragraph>• "Good-Goods"，意味着可以让用户在购物时，轻松找到性价比最高的商品。</Typography>
            <Typography paragraph>• "Go for Good Goods"，祝愿用户购物愉快，享受购物的乐趣。</Typography>
          </Box>

          {/* 右侧 Logo */}
          <Box
            component="img"
            src={LogoBig}
            alt="Good-Goods Logo"
            sx={{
              width: '250px', // 稍微减小图片尺寸
              height: 'auto',
              display: { xs: 'none', md: 'block' },
              ml: 0, // 添加左边距
            }}
          />
        </Box>
      </Paper>

      {/* 核心功能卡片 - 3列布局 */}
      <Grid container spacing={4} sx={{ mb: 6 }}>
        <Grid item xs={12} md={4}>
          <StyledCard>
            <CardContent>
              <Box sx={{ textAlign: 'center', mb: 2 }}>
                <RocketLaunchIcon color="primary" sx={{ fontSize: 40 }} />
              </Box>
              <Typography variant="h5" align="center" gutterBottom>
                电商平台
              </Typography>
              <Typography align="center" color="text.secondary">
                数量迅速增长
                <br />
                商品种类繁多
              </Typography>
            </CardContent>
          </StyledCard>
        </Grid>
        <Grid item xs={12} md={4}>
          <StyledCard>
            <CardContent>
              <Box sx={{ textAlign: 'center', mb: 2 }}>
                <PrecisionManufacturingIcon color="primary" sx={{ fontSize: 40 }} />
              </Box>
              <Typography variant="h5" align="center" gutterBottom>
                商品比价
              </Typography>
              <Typography align="center" color="text.secondary">
                核心功能：旨在构建一个智能比价搜索系统，
                <br />
                利用爬虫技术与数据分析，促进商品与用户有效连接。
              </Typography>
            </CardContent>
          </StyledCard>
        </Grid>
        <Grid item xs={12} md={4}>
          <StyledCard>
            <CardContent>
              <Box sx={{ textAlign: 'center', mb: 2 }}>
                <BusinessIcon color="primary" sx={{ fontSize: 40 }} />
              </Box>
              <Typography variant="h5" align="center" gutterBottom>
                用户需求
              </Typography>
              <Typography align="center" color="text.secondary">
                追求高性价比
                <br />
                信息鸿沟较大
              </Typography>
            </CardContent>
          </StyledCard>
        </Grid>
      </Grid>

      {/* 产品目标卡片 */}
      <Paper elevation={3} sx={{ p: 4, mb: 6 }}>
        <Typography variant="h5" gutterBottom color="primary.main">
          产品目标
        </Typography>
        <Typography>让用户买到心中性价比最高的商品，让天下没有难做的交易。</Typography>
      </Paper>

      {/* 使用方法卡片 */}
      <Paper elevation={3} sx={{ p: 4, mb: 6 }}>
        <Typography variant="h5" gutterBottom color="primary.main">
          使用方法
        </Typography>

        <Grid container spacing={4} sx={{ mt: 2 }}>
          {/* 商品搜索 */}
          <Grid item xs={12} md={6}>
            <StyledCard>
              <CardContent>
                <Box sx={{ textAlign: 'center', mb: 2 }}>
                  <SearchIcon color="primary" sx={{ fontSize: 40 }} />
                </Box>
                <Typography variant="h5" align="center" gutterBottom>
                  商品搜索
                </Typography>
                <Typography align="center" color="text.secondary">
                  • 在搜索框中输入想要查找的商品名称或关键词
                  <br />
                  • 系统会自动搜索多个电商平台的相关商品
                  <br />• 支持按价格、销量、评分等多个维度进行筛选
                </Typography>
              </CardContent>
            </StyledCard>
          </Grid>

          {/* 智能比价 */}
          <Grid item xs={12} md={6}>
            <StyledCard>
              <CardContent>
                <Box sx={{ textAlign: 'center', mb: 2 }}>
                  <CompareArrowsIcon color="primary" sx={{ fontSize: 40 }} />
                </Box>
                <Typography variant="h5" align="center" gutterBottom>
                  智能比价
                </Typography>
                <Typography align="center" color="text.secondary">
                  • 自动对比不同平台同款商品的价格
                  <br />
                  • 显示历史价格走势，帮助判断当前价格是否合理
                  <br />• 设置价格提醒，当商品降价时及时邮箱通知
                </Typography>
              </CardContent>
            </StyledCard>
          </Grid>

          {/* 个人中心 */}
          <Grid item xs={12} md={6}>
            <StyledCard>
              <CardContent>
                <Box sx={{ textAlign: 'center', mb: 2 }}>
                  <PersonIcon color="primary" sx={{ fontSize: 40 }} />
                </Box>
                <Typography variant="h5" align="center" gutterBottom>
                  个人中心
                </Typography>
                <Typography align="center" color="text.secondary">
                  • 注册登录后可以免费使用
                  <br />
                  • 收藏感兴趣的商品，助您做出最优选择
                  <br />• 查看搜索历史和收藏夹
                </Typography>
              </CardContent>
            </StyledCard>
          </Grid>

          {/* 一键购买 */}
          <Grid item xs={12} md={6}>
            <StyledCard>
              <CardContent>
                <Box sx={{ textAlign: 'center', mb: 2 }}>
                  <ShoppingCartIcon color="primary" sx={{ fontSize: 40 }} />
                </Box>
                <Typography variant="h5" align="center" gutterBottom>
                  一键购买
                </Typography>
                <Typography align="center" color="text.secondary">
                  • 选定商品后可直接跳转到对应电商平台
                  <br />
                  • 保证链接安全可靠
                  <br />• 支持多个主流电商平台
                </Typography>
              </CardContent>
            </StyledCard>
          </Grid>
        </Grid>
      </Paper>

      {/* 使用场景展示区 */}
      <Container sx={{ mt: 6, mb: 5 }}>
        <Typography
          variant="h4"
          align="center"
          sx={{
            mb: 6,
            fontWeight: 'bold',
            color: 'primary.main',
          }}
        >
          为什么选择 Good-Goods？
        </Typography>

        <Grid container spacing={3}>
          {features.map((item, index) => (
            <Grid item xs={12} sm={6} md={4} key={index}>
              <Paper
                sx={{
                  p: 3,
                  height: '100%',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  textAlign: 'center',
                  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
                  backgroundColor: 'background.paper',
                  '&:hover': {
                    transform: 'translateY(-8px)',
                    boxShadow: (theme: Theme) => theme.shadows[8],
                    backgroundColor: 'primary.light',
                    '& .MuiSvgIcon-root': {
                      color: 'white !important',
                    },
                    '& .MuiTypography-root': {
                      color: 'white',
                    },
                  },
                }}
              >
                {item.icon}
                <Typography
                  variant="h6"
                  sx={{
                    mt: 2,
                    mb: 1,
                    fontWeight: 'medium',
                  }}
                >
                  {item.title}
                </Typography>
                <Typography
                  variant="body1"
                  color="text.secondary"
                  sx={{
                    flexGrow: 1,
                  }}
                >
                  {item.description}
                </Typography>
              </Paper>
            </Grid>
          ))}
        </Grid>
      </Container>
    </Container>
  );
};

export default ProductInfo;
