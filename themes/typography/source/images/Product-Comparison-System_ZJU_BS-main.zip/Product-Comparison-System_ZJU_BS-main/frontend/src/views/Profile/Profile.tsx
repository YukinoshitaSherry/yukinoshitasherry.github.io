import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  TextField,
  Button,
  Grid,
  Card,
  CardContent,
  Chip,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  CircularProgress,
  Alert,
} from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import { userAPI } from '../../services/user';

interface UserProfile {
  id: number;
  username: string;
  email: string;
  avatar: string;
  created_at: string;
}

interface PriceAlert {
  id: number;
  product_id: number;
  old_price: number;
  latest_price: number;
  product: any;
  target_price: number;
  created_at: string;
  notified: boolean;
}

const Profile: React.FC = () => {
  console.log('Profile component rendered');
  const navigate = useNavigate();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState<Partial<UserProfile>>({});
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>([]);
  const [favorites, setFavorites] = useState<any[]>([]);
  const [searchHistory, setSearchHistory] = useState<string[]>([]);
  const [openDialog, setOpenDialog] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [hasChanges, setHasChanges] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // 添加路由保护
  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/sign-in');
      return;
    }
  }, [navigate]);

  // 获取用户信息
  useEffect(() => {
    const fetchUserData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const profileResponse = await userAPI.getUserInfo();
        console.log('Profile Response:', profileResponse);
        
        if (profileResponse.data) {
          setProfile(profileResponse.data.user);
          localStorage.setItem('userInfo', JSON.stringify(profileResponse.data.user));
          
          setPriceAlerts(profileResponse.data.alerts);
          
          const favoritesResponse = (await userAPI.getSubscribes()) as any;
          console.log('!! subscribeResponse', favoritesResponse);
          if (favoritesResponse.subscribes) {
            setFavorites(favoritesResponse.subscribes);
          }
          
          const history = localStorage.getItem('searchHistory');
          if (history) {
            setSearchHistory(JSON.parse(history).slice(0, 5));
          }
        } else {
          throw new Error('获取用户信息失败');
        }
      } catch (error) {
        console.error('Error fetching user data:', error);
        setError('获取用户信息失败');
        if (!localStorage.getItem('token')) {
          navigate('/sign-in');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [navigate]);

  const handleEdit = () => {
    setEditData({
      username: profile?.username,
    });
    setEditMode(true);
    setHasChanges(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newData = { ...editData, username: e.target.value };
    setEditData(newData);
    setHasChanges(newData.username !== profile?.username);
  };

  const handleSave = async () => {
    try {
      const response = await userAPI.updateProfile(editData);
      setProfile(prev => prev ? { ...prev, ...editData } : null);
      setEditMode(false);
      setHasChanges(false);
    } catch (error) {
      console.error('Failed to update profile:', error);
    }
  };

  const handleAvatarUpdate = async (file: File) => {
    try {
      await userAPI.updateAvatar(file);
      // 刷新用户信息
      const profileResponse = await userAPI.updateProfile({});
      setProfile(profileResponse.data);
    } catch (error) {
      console.error('Failed to update avatar:', error);
    }
  };

  if (!profile || loading) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4, textAlign: 'center' }}>
        <CircularProgress />
      </Container>
    );
  }

  if (error) {
    return (
      <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
        <Alert severity="error">{error}</Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4, pt: 12 }}>
      {/* 基础信息部分 */}
      <Paper elevation={3} sx={{ p: 3, mb: 4 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
          <Typography variant="h5">基础信息</Typography>
          {!editMode && (
            <IconButton onClick={handleEdit}>
              <EditIcon />
            </IconButton>
          )}
        </Box>

        <Grid container spacing={3}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="用户名"
              value={editMode ? editData.username : profile.username}
              onChange={handleInputChange}
              disabled={!editMode}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="邮箱"
              value={profile.email}
              disabled
            />
          </Grid>
        </Grid>

        {editMode && (
          <Box sx={{ mt: 3, display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
            <Button onClick={() => setEditMode(false)}>取消</Button>
            <Button variant="contained" onClick={handleSave}>保存</Button>
          </Box>
        )}
      </Paper>

      {/* 价格提醒商品部分 */}
      <Typography variant="h5" gutterBottom>价格提醒</Typography>
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {priceAlerts.map((alert) => (
          <Grid item xs={12} sm={6} md={4} key={alert.id}>
            <Card>
              <CardContent>
                <Typography variant="subtitle1">
                  <a href={`/product/${alert.product_id}`} rel="noopener noreferrer">
                    {alert.product.name}
                  </a>
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  旧价格: ¥{alert.old_price}
                </Typography>
                <Typography variant="body2" color="error">
                  新价格: ¥{alert.latest_price}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  发现时间: {new Date(alert.created_at).toLocaleDateString()}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* 订阅商品部分 */}
      <Typography variant="h5" gutterBottom>订阅商品</Typography>
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {favorites.map((favorite) => (
          <Grid item xs={12} sm={6} md={4} key={favorite.product_id}>
            <Card>
              <CardContent>
                <Typography variant="subtitle1">
                  <a href={`/product/${favorite.product_id}`} rel="noopener noreferrer">
                    {favorite.product.name}
                  </a>
                </Typography>
                <Typography variant="body2" color="error">
                  目标价格: ¥{favorite.target_price}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  创建时间: {new Date(favorite.created_at).toLocaleDateString()}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* 搜索历史部分 */}
      <Typography variant="h5" gutterBottom>最近搜索</Typography>
      <Paper sx={{ p: 2 }}>
        <Box sx={{ display: 'flex', gap: 1 }}>
          {searchHistory.length > 0 ? (
            searchHistory.map((term, index) => (
              <Chip
                key={index}
                label={term}
                size="small"
                sx={{ bgcolor: 'background.paper' }}
              />
            ))
          ) : (
            <Typography variant="body2" color="text.secondary">
              暂无搜索记录
            </Typography>
          )}
        </Box>
      </Paper>

      {/* 底部按钮 */}
      <Box sx={{ 
        position: 'fixed', 
        bottom: 0, 
        left: 0, 
        right: 0, 
        p: 2, 
        bgcolor: 'background.paper',
        borderTop: 1,
        borderColor: 'divider',
        display: 'flex',
        justifyContent: 'center',
        gap: 2
      }}>
        <Button 
          variant="contained" 
          onClick={handleSave}
          disabled={!hasChanges}
          sx={{ width: 120 }}
        >
          保存
        </Button>
        <Button 
          variant="outlined"
          onClick={() => navigate('/')}
          sx={{ width: 120 }}
        >
          返回
        </Button>
      </Box>
    </Container>
  );
};

export default Profile;
