// 商品基本信息接口
export interface Product {
  id: number;
  platform: string;
  external_id: string;
  name: string;
  category: string;
  description: string;
  image_url: string;
  latest_price: number;
  created_at: string;
  updated_at: string;
}

// 商品价格信息接口
export interface PriceInfo {
  id: number;
  product_id: number;
  platform: string;
  price: number;
  link: string;
  created_at: string;
}

// 价格历史记录接口
export interface PriceHistory {
  id: number;
  product_id: number;
  platform: string;
  price: number;
  checked_at: string;
}

// 搜索请求参数接口
export interface SearchParams {
  keyword?: string;
  category?: string;
  platform?: string;
  min_price?: number;
  max_price?: number;
  page?: number;
  per_page?: number;
}

// 商品详情响应接口
export interface ProductDetailResponse {
  code: number;
  msg: string;
  product: Product;
  prices: PriceHistory[];
  related_products: Product[];
}

// 用户订阅响应接口
export interface SubscribeResponse {
  code: number;
  msg: string;
  data: {
    subscriptions: Array<{
      id: number;
      user_id: number;
      product_id: number;
      created_at: string;
      product: Product;
    }>;
  };
} 