import Fuse from 'fuse.js';
import { useState, useMemo } from 'react';

interface FuzzySearchOptions<T> {
  data: T[];
  keys: string[];
  threshold?: number;
}

export function useFuzzySearch<T>({ data, keys, threshold = 0.3 }: FuzzySearchOptions<T>) {
  const [searchTerm, setSearchTerm] = useState('');
  
  const fuse = useMemo(() => {
    return new Fuse(data, {
      keys,
      threshold,
      shouldSort: true,
    });
  }, [data, keys, threshold]);

  const results = useMemo(() => {
    if (!searchTerm) return data;
    return fuse.search(searchTerm).map(result => result.item);
  }, [fuse, searchTerm, data]);

  return {
    searchTerm,
    setSearchTerm,
    results,
  };
}