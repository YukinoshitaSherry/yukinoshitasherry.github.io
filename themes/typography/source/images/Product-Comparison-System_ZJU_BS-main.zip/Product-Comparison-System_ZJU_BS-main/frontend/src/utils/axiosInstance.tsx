import axios from 'axios';

// 创建 axios 实例
export const axiosInstance = axios.create({
  baseURL: 'http://localhost:8000', // 后端接口基础 URL
  timeout: 1000, // 请求超时时间
  headers: {
    'Content-Type': 'application/json', // 请求内容类型
  },
});

// 添加请求拦截器
axiosInstance.interceptors.request.use(
  (config) => {
    // 动态从 localStorage 中获取 token
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    // 处理请求错误
    console.error('Request error:', error);
    return Promise.reject(error);
  }
);

// 添加响应拦截器
axiosInstance.interceptors.response.use(
  (response) => {
    // 统一处理成功响应
    return response;
  },
  (error) => {
    // 处理响应错误
    if (error.response?.status === 401) {
      console.warn('Unauthorized, please log in again.');
      // 可以添加自动跳转登录页逻辑
    }
    return Promise.reject(error);
  }
);
