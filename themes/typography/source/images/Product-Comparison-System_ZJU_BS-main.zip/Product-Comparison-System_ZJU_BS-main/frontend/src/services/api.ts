import axios from 'axios';

const BASE_URL = 'http://localhost:8132/api';

export const api = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// 请求拦截器 - 添加token
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// 响应拦截器 - 处理错误
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    if (error.response?.status === 401) {
      // 未授权,清除token并跳转到登录页
      localStorage.removeItem('token');
      window.location.href = '/sign-in';
    }
    return Promise.reject(error);
  }
);

export function getImageProxy(url: string): string {
  return `${BASE_URL}/img-proxy/${url}`;
}

export function getPlatformName(platform: string): string {
  if (platform === 'jd') {
    return '京东';
  }
  if (platform === 'taobao') {
    return '淘宝';
  }
  if (platform === 'pdd') {
    return '拼多多';
  }
  if (platform === 'suning') {
    return '苏宁易购';
  }
  if (platform === 'amazon') {
    return '亚马逊(中国)';
  }
  return platform;
}
