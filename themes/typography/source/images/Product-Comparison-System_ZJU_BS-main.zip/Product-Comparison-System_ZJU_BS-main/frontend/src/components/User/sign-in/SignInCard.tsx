import * as React from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import MuiCard from '@mui/material/Card';
import Checkbox from '@mui/material/Checkbox';
import Divider from '@mui/material/Divider';
import FormLabel from '@mui/material/FormLabel';
import FormControl from '@mui/material/FormControl';
import FormControlLabel from '@mui/material/FormControlLabel';
import Link from '@mui/material/Link';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import { Alert, Snackbar } from '@mui/material';

import { styled } from '@mui/material/styles';

import ForgotPassword from './ForgotPassword';
import SitemarkIcon  from '../../SitemarkIcon';
import { axiosInstance } from '../../../utils/axiosInstance'

import { useNavigate } from 'react-router-dom';
import { authAPI } from '../../../services/auth';
import LogoBig from '../../../assets/img/logo-big.jpg';
import IconButton from '@mui/material/IconButton';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import InputAdornment from '@mui/material/InputAdornment';


const Card = styled(MuiCard)(({ theme }) => ({
  display: 'flex',
  flexDirection: 'column',
  alignSelf: 'center',
  width: '100%',
  padding: theme.spacing(4),
  gap: theme.spacing(2),
  boxShadow:
    'hsla(220, 30%, 5%, 0.05) 0px 5px 15px 0px, hsla(220, 25%, 10%, 0.05) 0px 15px 35px -5px',
  [theme.breakpoints.up('sm')]: {
    width: '450px',
  },
  ...theme.applyStyles('dark', {
    boxShadow:
      'hsla(220, 30%, 5%, 0.5) 0px 5px 15px 0px, hsla(220, 25%, 10%, 0.08) 0px 15px 35px -5px',
  }),
}));

async function hashPassword(password: string | undefined) {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, '0')).join('');
}

export default function SignInCard() {
  const [emailError, setEmailError] = React.useState(false);
  const [emailErrorMessage, setEmailErrorMessage] = React.useState('');
  const [passwordError, setPasswordError] = React.useState(false);
  const [passwordErrorMessage, setPasswordErrorMessage] = React.useState('');
  const [open, setOpen] = React.useState(false);
  const navigate = useNavigate();
  const [error, setError] = React.useState('');
  const [alertOpen, setAlertOpen] = React.useState(false);
  const [alertMessage, setAlertMessage] = React.useState('');
  const [alertSeverity, setAlertSeverity] = React.useState<'success' | 'error'>('success');
  const [showPassword, setShowPassword] = React.useState(false);
  const [formAlert, setFormAlert] = React.useState<{show: boolean; message: string}>({
    show: false,
    message: ''
  });

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!validateInputs()) return;

    const data = new FormData(event.currentTarget);
    
    try {
      const response = await authAPI.login({
        email: data.get('email') as string,
        password: data.get('password') as string
      });

      if (response.code === 0) {
        if (response.data?.token) {
          localStorage.setItem('token', response.data.token);
          localStorage.setItem('userInfo', JSON.stringify(response.data.user));
        }
        
        setAlertSeverity('success');
        setAlertMessage('登录成功');
        setAlertOpen(true);
        
        setTimeout(() => {
          navigate('/profile');
        }, 1000);
      } else {
        setAlertSeverity('error');
        let errorMessage = '登录失败';
        if (response.msg.includes('email')) {
          errorMessage = '邮箱不存在，请检查邮箱地址';
        } else if (response.msg.includes('password')) {
          errorMessage = '密码错误，请重新输入';
        } else if (response.msg.includes('verify')) {
          errorMessage = '账号未验证，请先验证邮箱';
        } else {
          errorMessage = response.msg || '登录失败，请稍后重试';
        }
        setAlertMessage(errorMessage);
        setAlertOpen(true);
      }
    } catch (error: any) {
      console.error('Login error:', error);
      setAlertSeverity('error');
      setAlertMessage(error.response?.data?.msg || '账号或密码错误');
      setAlertOpen(true);
    }
  };

  const validateInputs = () => {
    const email = document.getElementById('email') as HTMLInputElement;
    const password = document.getElementById('password') as HTMLInputElement;

    let isValid = true;
    let errorMessages = [];

    if (!email.value || !/\S+@\S+\.\S+/.test(email.value)) {
      setEmailError(true);
      setEmailErrorMessage('请输入有效的邮箱地址');
      errorMessages.push('邮箱格式不正确');
      isValid = false;
    } else {
      setEmailError(false);
      setEmailErrorMessage('');
    }

    if (!password.value || password.value.length < 6) {
      setPasswordError(true);
      setPasswordErrorMessage('密码长度至少为6位');
      errorMessages.push('密码格式不正确');
      isValid = false;
    } else {
      setPasswordError(false);
      setPasswordErrorMessage('');
    }

    if (!isValid) {
      setFormAlert({
        show: true,
        message: errorMessages.join('，')
      });
    }

    return isValid;
  };

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event: React.MouseEvent<HTMLButtonElement>) => {
    event.preventDefault();
  };

  return (
    <>
      <Card variant="outlined" sx={{ width: '100%', maxWidth: '450px', p: 4 }}>
        <Box
          component="img"
          src={LogoBig}
          alt="Good-Goods Logo"
          sx={{ 
            width: '150px',
            height: 'auto',
            mb: 4,
            display: 'block',
            margin: '0 auto'
          }}
        />
        <Typography
          component="h1"
          variant="h5"
          sx={{ width: '100%', fontSize: 'clamp(2rem, 10vw, 2.15rem)' }}
        >
          Sign in
        </Typography>
        <Box
          component="form"
          onSubmit={handleSubmit}
          noValidate
          sx={{ display: 'flex', flexDirection: 'column', width: '100%', gap: 2 }}
        >
          <FormControl>
            <FormLabel htmlFor="email">Email</FormLabel>
            <TextField
              error={emailError}
              helperText={emailErrorMessage}
              id="email"
              type="email"
              name="email"
              placeholder="your@email.com"
              autoComplete="email"
              autoFocus
              required
              fullWidth
              variant="outlined"
              color={emailError ? 'error' : 'primary'}
            />
          </FormControl>
          <FormControl>
            <FormLabel htmlFor="password">Password</FormLabel>
            <TextField
              error={passwordError}
              helperText={passwordErrorMessage}
              name="password"
              placeholder="••••••"
              type={showPassword ? 'text' : 'password'}
              id="password"
              autoComplete="current-password"
              required
              fullWidth
              variant="outlined"
              color={passwordError ? 'error' : 'primary'}
              InputProps={{
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={handleClickShowPassword}
                      onMouseDown={handleMouseDownPassword}
                      edge="end"
                    >
                      {!showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
            />
          </FormControl>
          <FormControlLabel
            control={<Checkbox value="remember" color="primary" />}
            label="Remember me"
          />
          <Button 
            type="submit" 
            fullWidth 
            variant="contained"
          >
            Sign in
          </Button>
          <Typography sx={{ textAlign: 'center' }}>
            Don&apos;t have an account?{' '}
            <span>
              <Link
                href="/sign-up"
                variant="body2"
                sx={{ alignSelf: 'center' }}
              >
                Sign up
              </Link>
            </span>
          </Typography>
        </Box>
        <Divider></Divider>
        {alertOpen && (
          <Alert 
            severity={alertSeverity}
            onClose={() => setAlertOpen(false)}
            sx={{ mt: 2 }}
          >
            {alertMessage}
          </Alert>
        )}
        {formAlert.show && (
          <Alert 
            severity="warning"
            onClose={() => setFormAlert({show: false, message: ''})}
            sx={{ mb: 2 }}
          >
            {formAlert.message}
          </Alert>
        )}
      </Card>
    </>
  );
}
