import React from 'react';
import { Container, Grid, Typography, Box, Alert, CircularProgress } from '@mui/material';
import ProductCard from '../../components/Product/ProductCard';
import SearchBar from '../../components/Search/SearchBar';
import { useLocation, useNavigate } from 'react-router-dom';
import type { Product } from '../../types/product';
import { productAPI } from '../../services/product';
import { SearchParams, SearchMode, SearchResponse } from '../../types/api';

const SearchResults: React.FC = () => {
  const location = useLocation();
  // 添加调试日志
  console.log('SearchResults mounted');
  console.log('Location:', location);
  
  const navigate = useNavigate();
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState<string | null>(null);
  const [products, setProducts] = React.useState<Product[]>([]);
  const [hasSearched, setHasSearched] = React.useState(false);
  const [page, setPage] = React.useState(1);
  const [hasMore, setHasMore] = React.useState(true);
  const PAGE_SIZE = 12; // 每页显示12个商品

  const fetchSearchResults = async (keywords: string | string[]) => {
    setLoading(true);
    setError(null);
    
    try {
      const searchParams = new URLSearchParams(location.search);
      const searchMode = searchParams.get('mode') as SearchMode || 'exact';
      
      console.log('Search params:', new URLSearchParams(location.search));
      
      const response = await productAPI.searchProducts({ 
        keyword: Array.isArray(keywords) ? keywords.join('+') : keywords,
        mode: searchMode,
      });
      
      console.log('Search response:', response);
      
      if (response.code === 200) {
        if (response.products && Array.isArray(response.products)) {
          setProducts(response.products);
          setHasMore(response.products.length === PAGE_SIZE);
          if (response.products.length === 0) {
            setError('未找到相关商品');
          }
        } else {
          setError('返回数据格式错误');
          console.error('返回数据格式错误:', response);
        }
      } else {
        setError('搜索失败，请稍后重试');
      }
    } catch (err) {
      console.error('Search error:', err);
      setError('搜索失败，请稍后重试');
    } finally {
      setLoading(false);
      setHasSearched(true);
    }
  };

  
  

  React.useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const keyword = searchParams.get('keyword');
    console.log(keyword);
        
    if (keyword && keyword.trim()) {
      setHasSearched(true);
      const keywords = keyword.split(/\s+/g).filter(k => k.trim());
      fetchSearchResults(keywords.length > 1 ? keywords : keyword);
    } else {
      setHasSearched(false);
      setProducts([]);
      setError(null);
    }
  }, [location.search]);

  return (
    <Container maxWidth="lg" sx={{ mt: 15, mb: 8 }}>
      <SearchBar />
      {hasSearched && (
        <Box sx={{ mt: 4 }}>
          {error && page === 1 ? (
            <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>
          ) : (
            <>
              <Typography variant="h5" gutterBottom>
                搜索结果 ({products.length})
              </Typography>
              <Grid container spacing={3}>
                {products.map((product) => (
                  <Grid item xs={12} sm={6} md={4} key={product.id}>
                    <ProductCard 
                      product={product}
                      onViewDetail={() => navigate(`/product/${product.id}`)}
                    />
                  </Grid>
                ))}
              </Grid>
              {loading && (
                <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
                  <CircularProgress />
                </Box>
              )}
            </>
          )}
        </Box>
      )}
    </Container>
  );
};

export default SearchResults;
