import { api } from './api';

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  email: string;
  username: string;
  password: string;
}

export interface AuthResponse {
  code: number;
  msg: string;
  data?: {
    token: string;
    user: {
      id: number;
      username: string;
      email: string;
    };
  };
}

export const authAPI = {
  login: async (data: LoginRequest): Promise<AuthResponse> => {
    return api.post('/login', data);
  },

  register: async (data: RegisterRequest): Promise<AuthResponse> => {
    return api.post('/register', data);
  },

  logout: async (): Promise<void> => {
    return api.post('/logout');
  },

  // 获取当前用户信息
  getCurrentUser: async () => {
    return api.get('/user');
  },
};
