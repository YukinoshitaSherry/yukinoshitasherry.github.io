import * as React from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  Container,
  Typography,
  Link,
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Stack,
} from '@mui/material';

import CloseIcon from '@mui/icons-material/Close';
import { useState } from 'react';

export default function Hero() {
  const navigate = useNavigate();
  const [openTerms, setOpenTerms] = useState(false);

  const handleOpenTerms = () => setOpenTerms(true);
  const handleCloseTerms = () => setOpenTerms(false);

  const handleStartNow = () => {
    navigate('/search');
  };

  return (
    <Box
      id="hero"
      sx={(theme) => ({
        width: '100%',
        backgroundRepeat: 'no-repeat',
        backgroundImage:
          'radial-gradient(ellipse 80% 50% at 50% -20%, hsl(210, 100%, 90%), transparent)',
        ...theme.applyStyles('dark', {
          backgroundImage:
            'radial-gradient(ellipse 80% 50% at 50% -20%, hsl(210, 100%, 16%), transparent)',
        }),
      })}
    >
      <Container
        sx={{
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          pt: { xs: 14, sm: 20 },
          pb: { xs: 8, sm: 12 },
        }}
      >
        <Stack
          spacing={2}
          useFlexGap
          sx={{ alignItems: 'center', width: { xs: '100%', sm: '70%' } }}
        >
          <Box sx={{ 
            display: 'flex', 
            flexDirection: 'column',
            alignItems: 'center', 
            gap: 2,
            width: '100%',
          }}>
            <Box 
              component="img"
              src="/src/assets/img/logo.png"  
              alt="Good-Goods Logo"
              sx={{ 
                position: 'relative',
                display: 'block',
                margin: '0 auto',
                width: {
                  xs: '80px',
                  sm: '80px',
                  md: '100px',
                },
                height: 'auto',
                mb: 1,
                maxWidth: '100%',
              }}
            />
            <Typography
              variant="h1"
              sx={{
                fontSize: '45px',
                display: 'flex',
                flexDirection: { xs: 'column', sm: 'row' },
                alignItems: 'center',
              }}
            >
              Good-Goods&nbsp;
              <Typography
                component="span"
                variant="h1"
                sx={(theme) => ({
                  fontSize: '36px',
                  color: 'primary.main',
                  ...theme.applyStyles('dark', {
                    color: 'primary.light',
                  }),
                })}
              >
                商品比价系统
              </Typography>
            </Typography>
          </Box>
          <Typography
            sx={{
              textAlign: 'center',
              fontSize: '24px',
              color: 'text.secondary',
              width: { sm: '100%', md: '100%' },
            }}
          >
            智能比价系统，助您轻松购物
          </Typography>
          <Typography
            sx={{
              textAlign: 'center',
              fontSize: '16px',
              color: 'text.secondary',
              width: { sm: '100%', md: '100%' },
            }}
          >
            Find the best deals across multiple platforms with our smart price comparison system.
          </Typography>
          
          <Button
            variant="contained"
            color="primary"
            size="large"              
            onClick={handleStartNow}
            sx={{ 
              fontSize: '1.2rem',
              px: 4,
              py: 1.5,
              height: '40px',
              borderRadius: '8px',
              minWidth: '200px',
              whiteSpace: 'nowrap',
              mt: 3
            }}
          >
            Start now
          </Button>

          <Typography
            sx={{
              mt: 2,
              fontSize: '1.1rem',
              color: 'text.secondary'
            }}
          >
            By clicking "Start now" you agree to our{' '}
            <Link
              component="button"
              onClick={handleOpenTerms}
              sx={{
                textDecoration: 'none',
                '&:hover': {
                  textDecoration: 'underline',
                  color: 'primary.main',
                },
              }}
            >
              Terms & Conditions
            </Link>
            .
          </Typography>
        </Stack>
      </Container>

      {/* Terms & Conditions 对话框 */}
      <Dialog
        open={openTerms}
        onClose={handleCloseTerms}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle sx={{ 
          textAlign: 'center',
          borderBottom: '1px solid',
          borderColor: 'divider',
          position: 'relative'
        }}>
          Terms & Conditions
          <IconButton
            onClick={handleCloseTerms}
            sx={{
              position: 'absolute',
              right: 8,
              top: 8
            }}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent>
          <Box sx={{ py: 2 }}>
            <Typography variant="h6" gutterBottom color="primary.main">
              隐私政策 Privacy Policy
            </Typography>
            <Typography paragraph>
              • 我们承诺保护您的个人隐私，未经您的许可，我们不会向第三方披露您的个人信息。
              <br />
              We are committed to protecting your privacy. We will not disclose your personal information to third parties without your permission.
            </Typography>

            <Typography variant="h6" gutterBottom color="primary.main" sx={{ mt: 3 }}>
              用户协议 User Agreement
            </Typography>
            <Typography paragraph>
              • 用户在使用本系统时应遵守相关法律法规，不得用于非法用途。
              <br />
              Users must comply with relevant laws and regulations when using this system and must not use it for illegal purposes.
              <br />
              • 用户应对账号安全负责，请妥善保管账号密码。
              <br />
              Users are responsible for account security. Please keep your account password safe.
            </Typography>

            <Typography variant="h6" gutterBottom color="primary.main" sx={{ mt: 3 }}>
              服务条款 Service Terms
            </Typography>
            <Typography paragraph>
              • 我们保留随时修改或中断服务的权利，修改后的协议条款会在网站上公布。
              <br />
              We reserve the right to modify or interrupt services at any time. Modified terms will be published on the website.
              <br />
              • 用户使用本系统即表示同意接受本协议的所有条款。
              <br />
              By using this system, users agree to accept all terms of this agreement.
            </Typography>

            <Typography variant="h6" gutterBottom color="primary.main" sx={{ mt: 3 }}>
              免责声明 Disclaimer
            </Typography>
            <Typography paragraph>
              • 本系统提供的商品价格信息仅供参考，实际价格以各电商平台显示为准。
              <br />
              The product price information provided by this system is for reference only. Actual prices are subject to display on respective e-commerce platforms.
              <br />
              • 对于因使用本系统而引起的任何直接或间接损失，本系统不承担责任。
              <br />
              This system is not liable for any direct or indirect losses arising from the use of this system.
            </Typography>
          </Box>
        </DialogContent>
      </Dialog>
    </Box>
  );
}
