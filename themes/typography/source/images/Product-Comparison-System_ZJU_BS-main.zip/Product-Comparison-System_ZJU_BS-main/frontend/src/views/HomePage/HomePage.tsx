import * as React from 'react';
import { Theme, ThemeProvider, createTheme } from '@mui/material/styles';
import type { PaletteMode } from '@mui/material';
import CssBaseline from '@mui/material/CssBaseline';
import Hero from '../../components/Hero';
import getMPTheme from '../../theme/getMPTheme';
import AppAppBar from '../../components/Layout/AppAppBar';

interface HomePageProps {

  mode: PaletteMode;

  setMode: React.Dispatch<React.SetStateAction<PaletteMode>>;

}




export default function HomePage({ mode, setMode }: HomePageProps) {
  const [showCustomTheme, setShowCustomTheme] = React.useState<boolean>(true);
  const MPTheme = createTheme(getMPTheme(mode));
  const defaultTheme = createTheme({ palette: { mode } });

  // This code only runs on the client side, to determine the system color preference
  React.useEffect(() => {
    // Check if there is a preferred mode in localStorage
    const savedMode = localStorage.getItem('themeMode') as PaletteMode | null;
    if (savedMode) {
      setMode(savedMode);
    } else {
      // If no preference is found, it uses system preference
      const systemPrefersDark = window.matchMedia(
        '(prefers-color-scheme: dark)',
      ).matches;
      setMode(systemPrefersDark ? 'dark' : 'light');
    }
  }, [setMode]);

  return (
    
      <ThemeProvider theme={showCustomTheme ? MPTheme : defaultTheme}>
        <AppAppBar mode={mode} setMode={setMode} />

        <CssBaseline enableColorScheme />
        <Hero />
        
      </ThemeProvider>
  );
}
