// 用户相关接口
export interface User {
    id: number;
    username: string;
    email: string;
    avatar: string;
    created_at: string;
  }