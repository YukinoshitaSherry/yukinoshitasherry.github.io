import React from 'react';
import { Card, CardContent, CardMedia, Typography, Button, Box, Chip, Stack } from '@mui/material';
import { styled } from '@mui/material/styles';
import type { Product } from '../../types/product';
import { getImageProxy, getPlatformName } from '../../services/api';


const StyledCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: 'transform 0.2s',
  '&:hover': {
    transform: 'translateY(-4px)',
  },
}));

interface ProductCardProps {
  product: Product;
  onViewDetail: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onViewDetail }) => {
  const formatDisplayValue = (value: string | null | undefined): string => {
    if (!value || value === 'none' || value === '') {
      if (value === 'category') {
        return '数码';
      }
      return '数据暂缺';
    }
    return value;
  };

  return (
    <StyledCard>
      <CardMedia component="img" height="200" image={getImageProxy(product.image_url)} alt={product.name} sx={{ objectFit: 'contain' }} />
      <CardContent sx={{ flexGrow: 1 }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
          <Typography
            variant="h6"
            component="div"
            sx={{
              display: 'flex',
              alignItems: 'center',
              width: '100%',
              gap: 0.5,
            }}
          >
            <Box
              sx={{
                minWidth: 0,
                overflow: 'hidden',
                display: '-webkit-box',
                WebkitLineClamp: 2,
                WebkitBoxOrient: 'vertical',
                lineHeight: 1.2,
                fontSize: '0.82em',
                mb: 0.5,
              }}
            >
              {product.name}
            </Box>
            <Box sx={{ flexGrow: 1 }} />
            <Typography
              variant="h6"
              color="error"
              sx={{
                whiteSpace: 'nowrap',
                flexShrink: 0,
              }}
            >
              ¥{product.latest_price}
            </Typography>
          </Typography>
        </Box>
        <Stack
          direction="row"
          spacing={1}
          sx={{
            width: '100%',
            justifyContent: 'space-between',
          }}
        >
          <Box sx={{ display: 'flex', gap: 1 }}>
            <Chip label={`${getPlatformName(product.platform)}`} size="small" color="primary" />
            {/* <Chip label={product.category} size="small" /> */}
          </Box>
          <Button size="small" color="primary" onClick={onViewDetail}>
            查看详情
          </Button>
        </Stack>
      </CardContent>
    </StyledCard>
  );
};

export default ProductCard;
