import * as React from 'react';
import CssBaseline from '@mui/material/CssBaseline';
import Stack from '@mui/material/Stack';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import type { PaletteMode } from '@mui/material';
import getSignInSideTheme from '../../../theme/getSignInSideTheme';
import SignInCard from './SignInCard';
import LogoBig from '../../../assets/img/logo-big.jpg';

interface SignInProps {

  mode: PaletteMode;

  setMode: React.Dispatch<React.SetStateAction<PaletteMode>>;

}
//nihao

export default function SignIn({ mode, setMode }: SignInProps) {
  const [showCustomTheme, setShowCustomTheme] = React.useState(true);
  // 设置默认主题为亮色模式
  React.useEffect(() => {
    window.scrollTo(0,0);
    // 直接设置为亮色模式
    setMode('light');
    // 保存到本地存储
    localStorage.setItem('themeMode', 'light');
  }, []);

  const defaultTheme = createTheme({ 
    palette: { 
      mode: 'light',
      background: {
        default: '#ffffff',
        paper: '#ffffff'
      }
    } 
  });
  const SignInSideTheme = createTheme(getSignInSideTheme('light'));

  return (
    
      <ThemeProvider theme={showCustomTheme ? SignInSideTheme : defaultTheme}>
        <CssBaseline enableColorScheme />
        
        <Stack
          direction="column"
          component="main"
          sx={[
            {
              justifyContent: 'space-between',
              height: { xs: 'auto', md: '100%' },
            },
            (theme) => ({
              backgroundImage:
                'radial-gradient(ellipse at 70% 51%, hsl(210, 100%, 97%), hsl(0, 0%, 100%))',
              backgroundSize: 'cover',
              ...theme.applyStyles('dark', {
                backgroundImage:
                  'radial-gradient(at 70% 51%, hsla(210, 100%, 16%, 0.5), hsl(220, 30%, 5%))',
              }),
            }),
          ]}
        >
          <Stack
            direction={{ xs: 'column-reverse', md: 'row' }}
            sx={{
              justifyContent: 'center',
              gap: { xs: 6, sm: 12 },
              p: 2,
              m: 'auto',
            }}
          >
            {/* <Content /> */}
            <SignInCard />
          </Stack>
        </Stack>
      </ThemeProvider>
    
  );
}
