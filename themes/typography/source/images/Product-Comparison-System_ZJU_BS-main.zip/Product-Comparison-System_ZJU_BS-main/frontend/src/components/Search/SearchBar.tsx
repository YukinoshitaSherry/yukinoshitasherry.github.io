import React, { useState } from 'react';
import { Box, Paper, InputBase, IconButton, Chip, Typography, Select, MenuItem, FormControl, RadioGroup, FormControlLabel, Radio, Alert, Popover, Stack, List, ListItem, ListItemIcon, ListItemText } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import HistoryIcon from '@mui/icons-material/History';
import ClearIcon from '@mui/icons-material/Clear';
import DeleteIcon from '@mui/icons-material/Delete';
import { useNavigate } from 'react-router-dom';

type SearchMode = 'exact' | 'fuzzy' | 'multiple-and' | 'multiple-or';

const SearchBar: React.FC = () => {
  const navigate = useNavigate();
  const [keyword, setKeyword] = React.useState('');
  const [showHistory, setShowHistory] = React.useState(false);
  const [searchMode, setSearchMode] = React.useState<SearchMode>('exact');
  const [anchorEl, setAnchorEl] = React.useState<HTMLElement | null>(null);
  const [searchHistory, setSearchHistory] = React.useState<string[]>(() => {
    const saved = localStorage.getItem('searchHistory');
    return saved ? JSON.parse(saved) : [];
  });
  const [error, setError] = useState<string | null>(null);
  const [searchAlert, setSearchAlert] = React.useState<{show: boolean; message: string}>({
    show: false,
    message: ''
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!keyword.trim()) {
      setSearchAlert({
        show: true,
        message: '请输入搜索关键词'
      });
      return;
    }

    const newHistory = [keyword.trim(), ...searchHistory.filter(item => item !== keyword.trim())]
      .slice(0, 5);
    setSearchHistory(newHistory);
    localStorage.setItem('searchHistory', JSON.stringify(newHistory));
    
    const searchParams = new URLSearchParams();
    
    if (searchMode.startsWith('multiple')) {
      const keywords = keyword.split(/[,\s]+/).filter(k => k.trim());
      if (keywords.length <= 1) {
        setSearchAlert({
          show: true,
          message: '多项搜索请输入多个关键词，用逗号或空格分隔'
        });
        return;
      }
      searchParams.set('keyword', keywords.join(','));
    } else {
      searchParams.set('keyword', keyword.trim());
    }
    
    searchParams.set('mode', searchMode);
    navigate(`/search?${searchParams.toString()}`);
  };

  const handleClearResults = () => {
    setKeyword('');
    navigate('/search');
  };

  const handleClearHistory = () => {
    setSearchHistory([]);
    localStorage.setItem('searchHistory', JSON.stringify([]));
    setShowHistory(false);
  };

  const handleHistoryClick = (historyItem: string) => {
    setKeyword(historyItem);
    const searchParams = new URLSearchParams();
    searchParams.set('keyword', historyItem);
    searchParams.set('mode', searchMode);
    navigate(`/search?${searchParams.toString()}`);
    setShowHistory(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setKeyword(e.target.value);
    if (e.target.value.trim()) {
      setSearchAlert({show: false, message: ''});
    }
  };

  const handleShowHistory = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
    setShowHistory(true);
  };

  const handleCloseHistory = () => {
    setAnchorEl(null);
    setShowHistory(false);
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: '100%' }}>
      {searchAlert.show && (
        <Alert 
          severity="warning"
          onClose={() => setSearchAlert({show: false, message: ''})}
          sx={{ mb: 2, width: '100%', maxWidth: 800 }}
        >
          {searchAlert.message}
        </Alert>
      )}
      <Paper
        component="form"
        onSubmit={handleSearch}
        sx={{
          p: '4px 8px',
          display: 'flex',
          alignItems: 'center',
          width: '100%',
          maxWidth: 800,
          mx: 'auto',
          mt: 5,
          gap: 1
        }}
      >
        <Select
          value={searchMode}
          onChange={(e) => setSearchMode(e.target.value as typeof searchMode)}
          size="small"
          sx={{ width: 120 }}
        >
          <MenuItem value="exact">单项搜索</MenuItem>
          <MenuItem value="multiple">多项搜索</MenuItem>
        </Select>
        
        <InputBase
          sx={{ flex: 1 }}
          placeholder="搜索商品..."
          value={keyword}
          onChange={handleInputChange}
        />
        
        <Box sx={{ display: 'flex', gap: 0.5 }}>
          <IconButton type="submit" sx={{ p: 1 }}>
            <SearchIcon />
          </IconButton>
          <IconButton onClick={handleShowHistory} sx={{ p: 1 }}>
            <HistoryIcon />
          </IconButton>
          <IconButton onClick={handleClearResults} sx={{ p: 1 }}>
            <ClearIcon />
          </IconButton>
        </Box>
      </Paper>
      
      <Popover
        open={showHistory}
        anchorEl={anchorEl}
        onClose={handleCloseHistory}
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
      >
        <Box sx={{ p: 2, maxWidth: 300 }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 1 }}>
            <Typography variant="subtitle1">搜索历史</Typography>
            <IconButton size="small" onClick={handleClearHistory}>
              <DeleteIcon fontSize="small" />
            </IconButton>
          </Stack>
          {searchHistory.length > 0 ? (
            <List sx={{ width: '100%', maxWidth: 360 }}>
              {searchHistory.map((item, index) => (
                <ListItem
                  key={index}
                  button
                  onClick={() => handleHistoryClick(item)}
                  sx={{
                    '&:hover': {
                      backgroundColor: 'action.hover',
                    },
                  }}
                >
                  <ListItemIcon>
                    <HistoryIcon />
                  </ListItemIcon>
                  <ListItemText primary={item} />
                </ListItem>
              ))}
            </List>
          ) : (
            <Typography variant="body2" color="text.secondary">
              暂无搜索历史
            </Typography>
          )}
        </Box>
      </Popover>
    </Box>
  );
};

export default SearchBar;
