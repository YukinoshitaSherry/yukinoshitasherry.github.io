import React from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { PriceHistory } from "../../types/product";

interface PriceHistoryChartProps {
  data: PriceHistory[];
}

const PriceHistoryChart: React.FC<PriceHistoryChartProps> = ({ data }) => {
  const formattedData = data
    .map((item) => ({
      date:
        new Date(item.checked_at).toLocaleDateString() +
        " " +
        new Date(item.checked_at).toLocaleTimeString(),
      price: item.price,
    }))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .reverse();

  return (
    <ResponsiveContainer width="100%" height={400}>
      <LineChart data={formattedData}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Line
          type="monotone"
          dataKey="price"
          stroke="#8884d8"
          activeDot={{ r: 8 }}
        />
      </LineChart>
    </ResponsiveContainer>
  );
};

export default PriceHistoryChart;
