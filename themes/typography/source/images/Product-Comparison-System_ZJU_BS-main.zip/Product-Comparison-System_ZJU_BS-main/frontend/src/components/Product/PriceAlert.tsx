import React, { useState } from 'react';
import {
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Alert,
  Box,
  Typography
} from '@mui/material';
import NotificationsActiveIcon from '@mui/icons-material/NotificationsActive';
import { userAPI } from '../../services/user';

interface PriceAlertProps {
  productId: number;
  currentPrice: number;
}

const PriceAlert: React.FC<PriceAlertProps> = ({ productId, currentPrice }) => {
  const [open, setOpen] = useState(false);
  const [targetPrice, setTargetPrice] = useState(currentPrice);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleSubscribe = async () => {
    if (targetPrice >= currentPrice) {
      setError('目标价格必须低于当前价格');
      return;
    }

    try {
      await userAPI.createSubscribes({
        product_id: productId,
        target_price: targetPrice
      });
      setSuccess(true);
      setTimeout(() => setOpen(false), 1500);
    } catch (err) {
      setError('设置降价提醒失败，请稍后重试');
    }
  };

  return (
    <>
      <Button
        variant="outlined"
        color="primary"
        startIcon={<NotificationsActiveIcon />}
        onClick={() => setOpen(true)}
      >
        降价提醒
      </Button>

      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>设置降价提醒</DialogTitle>
        <DialogContent>
          <Box sx={{ mb: 2 }}>
            <Typography variant="body2" color="text.secondary">
              当商品价格低于目标价格时，我们会通过邮件通知您。
            </Typography>
          </Box>
          <TextField
            autoFocus
            margin="dense"
            label="目标价格"
            type="number"
            fullWidth
            value={targetPrice}
            onChange={(e) => setTargetPrice(Number(e.target.value))}
            error={targetPrice >= currentPrice}
            helperText={targetPrice >= currentPrice ? "目标价格必须低于当前价格" : ""}
          />
          {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
          {success && <Alert severity="success" sx={{ mt: 2 }}>设置成功！</Alert>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setOpen(false)}>取消</Button>
          <Button onClick={handleSubscribe} variant="contained">
            确认
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
};

export default PriceAlert;
