import * as React from 'react';
import { styled, alpha } from '@mui/material/styles';
import Box from '@mui/material/Box';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Button from '@mui/material/Button';
import IconButton from '@mui/material/IconButton';
import Container from '@mui/material/Container';
import Divider from '@mui/material/Divider';
import MenuItem from '@mui/material/MenuItem';
import Drawer from '@mui/material/Drawer';
import MenuIcon from '@mui/icons-material/Menu';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import Sitemark from '../../assets/img/logo.png';
import { useNavigate } from 'react-router-dom';
import { Menu, PaletteMode, Typography, Avatar } from '@mui/material';
import userImage from "../../assets/img/user.png";
import InfoIcon from '@mui/icons-material/Info';
import { authAPI } from '../../services/auth';


const StyledToolbar = styled(Toolbar)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'space-between',
  flexShrink: 0,
  borderRadius: `calc(${theme.shape.borderRadius}px + 8px)`,
  backdropFilter: 'blur(24px)',
  border: '1px solid',
  borderColor: theme.palette.divider,
  backgroundColor: alpha(theme.palette.background.default, 0.4),
  boxShadow: theme.shadows[1],
  padding: '8px 24px',
}));

interface AppAppBarProps {
  mode: PaletteMode;
  setMode: (mode: PaletteMode) => void;
}

export default function AppAppBar(props: AppAppBarProps) {
  const navigate = useNavigate();
  const [open, setOpen] = React.useState(false);
  
  // 从 localStorage 获取用户信息
  const userInfo = JSON.parse(localStorage.getItem("userInfo") || "{}");
  const token = localStorage.getItem("token");
  const isLoggedIn = Boolean(token); 

  const toggleDrawer = (newOpen: boolean) => () => {
    setOpen(newOpen);
  };

  const [anchorEl, setAnchorEl] = React.useState<null | HTMLElement>(null);

  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleGoUser = () => {
    if (isLoggedIn) {
      navigate('/profile');
      handleMenuClose();
    } else {
      navigate('/sign-in');
    }
  };

  const handleLogout = async () => {
    try {
      await authAPI.logout();
    } finally {
      // 无论退出API是否成功，都清除本地存储
      localStorage.removeItem("token");
      localStorage.removeItem("userInfo");
      navigate('/sign-in');
    }
    handleMenuClose();
  };

  return (
    <AppBar
      position="fixed"
      sx={{ boxShadow: 0, bgcolor: 'transparent', backgroundImage: 'none', mt: 4 }}
    >
      <Container maxWidth="lg">
        <StyledToolbar variant="dense" disableGutters>
          <Box sx={{ flexGrow: 1, display: 'flex', alignItems: 'center', px: 0 }}>
            <img 
              src={Sitemark} 
              alt="logo" 
              onClick={() => navigate('/')} 
              style={{ 
                cursor: 'pointer', 
                width: '40px',  // 缩小logo尺寸
                height: 'auto',
                marginRight: '40px' // 增加右边距
              }}
            />
            <Box sx={{ display: { xs: 'none', md: 'flex' } }}>
              <Button 
                variant="text" 
                color="info" 
                size="large"  // 改为 large
                sx={{
                  fontSize: '1.1rem',  // 增加字体大小
                  ml: 3  // 增加按钮间距
                }}
                onClick={() => navigate('/search')}
              >
                商品搜索
              </Button>
              <Button
                variant="text"
                color="info"
                size="large"
                onClick={() => navigate('/product-info')}
                sx={{
                  fontSize: '1.1rem',  // 增加字体大小
                  ml: 3  // 增加按钮间距
                }}
              >
                产品介绍
              </Button>
            </Box>
          </Box>
          {isLoggedIn ? (
              <>
                <Avatar
                  src={userInfo.avatar || '/default-avatar.png'}
                  alt={userInfo.username}
                  sx={{ 
                    cursor: 'pointer',
                    width: 35,
                    height: 35,
                    ml: 2,
                    '&:hover': {
                      opacity: 0.8,
                      transform: 'scale(1.05)',
                    },
                    transition: 'all 0.2s ease-in-out'
                  }}
                  onClick={() => navigate('/profile')}
                />
                <Button  size="small" onClick={handleMenuOpen}>
                  <Typography variant="body1">
                    {userInfo.username || "未填写姓名"}
                  </Typography>
                </Button>

                {/* 菜单组件 */}

                <Menu
                  anchorEl={anchorEl}
                  open={Boolean(anchorEl)}
                  onClose={handleMenuClose}
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "right",
                  }}
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "right",
                  }}
                  sx={{
                    "& .MuiPaper-root": {
                      width: "100px", // 让菜单适配文本长度
                    },
                  }}
                >
                  <MenuItem onClick={handleGoUser}>个人主页</MenuItem>
                  <MenuItem onClick={handleLogout}>退出登录</MenuItem>
                </Menu>
              </>
            ) : (
              
          <Box
            sx={{
              display: { xs: 'none', md: 'flex' },
              gap: 1,
              alignItems: 'center',
            }}
          >
            <Button color="primary" variant="text" size="small"
             onClick={() => {
              navigate('/sign-in')

             }}>
              Sign in
            </Button>
            <Button color="primary" variant="contained" size="small"
             onClick={() => {
              navigate('/sign-up')

             }}>
              Sign up
            </Button>
          </Box>
          
            )}






          <Box sx={{ display: { sm: 'flex', md: 'none' } }}>
            <IconButton aria-label="Menu button" onClick={toggleDrawer(true)}>
              <MenuIcon />
            </IconButton>
            <Drawer anchor="top" open={open} onClose={toggleDrawer(false)}>
              <Box sx={{ p: 2, backgroundColor: 'background.default' }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'stretch' }}>
                  <Box sx={{ display: 'flex', justifyContent: 'flex-end', p: 2 }}>
                    <IconButton onClick={toggleDrawer(false)}>
                      <CloseRoundedIcon />
                    </IconButton>
                  </Box>
                  <Divider sx={{ my: 3 }} />
                  <MenuItem onClick={() => navigate('/search')}>
                    商品搜索
                  </MenuItem>
                  <MenuItem onClick={() => navigate('/favorites')}>
                    我的收藏
                  </MenuItem>
                  <MenuItem onClick={() => navigate('/price-alerts')}>
                    降价提醒
                  </MenuItem>
                  {!isLoggedIn && (
                    <>
                      <MenuItem>
                        <Button 
                          color="primary" 
                          variant="contained" 
                          fullWidth
                          onClick={() => navigate('/sign-up')}
                        >
                          注册
                        </Button>
                      </MenuItem>
                      <MenuItem>
                        <Button 
                          color="primary" 
                          variant="outlined" 
                          fullWidth
                          onClick={() => navigate('/sign-in')}
                        >
                          登录
                        </Button>
                      </MenuItem>
                    </>
                  )}
                </Box>
              </Box>
            </Drawer>
          </Box>
        </StyledToolbar>
      </Container>
    </AppBar>
  );
}
