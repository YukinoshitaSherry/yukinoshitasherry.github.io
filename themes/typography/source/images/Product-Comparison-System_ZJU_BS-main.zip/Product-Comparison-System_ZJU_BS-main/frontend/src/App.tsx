import React from "react";
import { PaletteMode } from '@mui/material';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import HomePage from "./views/HomePage/HomePage";
import AppAppBar from "./components/Layout/AppAppBar";
import getMPTheme from "./theme/getMPTheme";
import SignUp from "./components/User/sign-up/SignUp";
import SignIn from "./components/User/sign-in/SignIn";
import CssBaseline from '@mui/material/CssBaseline';
import Profile from "./views/Profile/Profile";
import ProductDetail from './views/ProductDetail/ProductDetail';
import PrivateRoute from './components/PrivateRoute';
import SearchResults from './views/SearchResults/SearchResults';
import PriceAlert from './components/Product/PriceAlert';
import ProductInfo from "./views/HomePage/InfoPage";
import InfoPage from "./views/HomePage/InfoPage";

const App: React.FC = () => {
  const [mode, setMode] = React.useState<PaletteMode>('light');
  const MPTheme = createTheme(getMPTheme(mode));

  React.useEffect(() => {
    const savedMode = localStorage.getItem('themeMode') as PaletteMode | null;
    if (savedMode) {
      setMode(savedMode);
    } else {
      setMode('light');
    }
  }, []);

  return (
    <div style={{
      height: '100vh',
      width: '100vw',
      display: 'flex',
      flexDirection: 'column',
    }}>
      <ThemeProvider theme={MPTheme}>
        <CssBaseline />
        <BrowserRouter>
          <AppAppBar mode={mode} setMode={setMode} />
          <Routes>
            <Route path="/" element={<HomePage mode={mode} setMode={setMode} />} />
            <Route path="/sign-up" element={<SignUp mode={mode} setMode={setMode} />} />
            <Route path="/sign-in" element={<SignIn mode={mode} setMode={setMode} />} />
            <Route path="/profile" element={
              <PrivateRoute>
                <Profile />
              </PrivateRoute>
            } />
            <Route path="/product-info" element={<InfoPage />} />
            <Route path="/search" element={<SearchResults />} />
            <Route path="/price-alerts" element={
              <PrivateRoute>
                <PriceAlert productId={''} currentPrice={0} />
              </PrivateRoute>
            } />
            <Route path="/product/:id" element={
              <PrivateRoute>
                <ProductDetail />
              </PrivateRoute>
            } />
            <Route path="/login" element={<SignIn mode={mode} setMode={setMode} />} />
            <Route path="/register" element={<SignUp mode={mode} setMode={setMode} />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </ThemeProvider>
    </div>
  );
};

export default App;